import React from "react";

class Todo extends React.Component {
  render() {
    const { todo, index, deleteTodo, updateTodoStatus } = this.props;

    return (
      <div style={{ display: "flex", gap: "10px", marginBottom: "10px" }}>
        <input type="text" value={todo.text} readOnly />
        <select value={todo.status} onChange={(e) => updateTodoStatus(index, e.target.value)}>
          <option value="Todo">Todo</option>
          <option value="In Progress">In Progress</option>
          <option value="Done">Done</option>
        </select>
        <button onClick={() => deleteTodo(index)} style={{ backgroundColor: "red", color: "white", borderRadius: "10px"}}>
          Delete
        </button>
      </div>
    );
  }
}

export default Todo;
