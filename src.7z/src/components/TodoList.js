import React from "react";
import { connect } from "react-redux";
import { addTodo, deleteTodo, updateTodoStatus } from "../redux/todoReducer/actions";
import Todo from "./Todo";

class TodoList extends React.Component {
  state = {
    newTodo: "",
  };

  handleAddTodo = () => {
    if (this.state.newTodo.trim() === "") return;
    this.props.addTodo({ text: this.state.newTodo, status: "Todo" });
    this.setState({ newTodo: "" });
  };

  render() {
    return (
      <div style={{ width: "300px", margin: "auto", textAlign: "center" }}>
        <h2>Todo List</h2>
        <button onClick={this.handleAddTodo} style={{ backgroundColor: "green", color: "white", marginBottom: "10px" }}>
          Add Todo
        </button>
        {this.props.todos.map((todo, index) => (
          <Todo
            key={index}
            index={index}
            todo={todo}
            deleteTodo={this.props.deleteTodo}
            updateTodoStatus={this.props.updateTodoStatus}
          />
        ))}
        <input
          type="text"
          value={this.state.newTodo}
          onChange={(e) => this.setState({ newTodo: e.target.value })}
          placeholder="New Todo"
        />
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  todos: state.todo.todos,
});

export default connect(mapStateToProps, { addTodo, deleteTodo, updateTodoStatus })(TodoList);
